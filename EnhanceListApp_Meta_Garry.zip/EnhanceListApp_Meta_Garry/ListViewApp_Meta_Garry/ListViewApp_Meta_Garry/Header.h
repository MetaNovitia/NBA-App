//
//  Header.h
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 6/13/17.
//  Copyright © 2017 META 2. All rights reserved.
//

#ifndef Header_h
#define Header_h

@property (nonatomic, retain) NSAttributedString * iInfo;


#endif /* Header_h */
