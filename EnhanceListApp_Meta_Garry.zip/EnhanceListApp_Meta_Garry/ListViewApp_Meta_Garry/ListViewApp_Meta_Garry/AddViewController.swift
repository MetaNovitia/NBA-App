//
//  AddViewController.swift
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 6/7/17.
//  Copyright © 2017 META 2. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController {

    @IBOutlet var addTeam: UITextField!
    @IBOutlet var addImage: UITextField!
    @IBOutlet var addInfo: UITextField!
    @IBOutlet var addW: UITextField!
    @IBOutlet var addL: UITextField!
    @IBOutlet var sv: UIButton!
    @IBOutlet var cncl: UIButton!
    
    var newNBA : ObjectMO!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancelbtn(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func savebtn(_ sender: Any) {
//        newNBA(Object(iTeams: self.addTeam.text!, iImage: UIImage(named: self.addImage.text!)!, iInfo: self.addInfo.text!, iW: self.addW.text!, iL:self.addL.text!))
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            newNBA = ObjectMO(context: appDelegate.persistentContainer.viewContext)
            
            
            newNBA.iTeams = addTeam.text!
            newNBA.iImage = NSData(data: UIImagePNGRepresentation(UIImage(named: addImage.text!)!)!)
            newNBA.iInfo = addInfo.attributedText!
            newNBA.iW = addW.text!
            newNBA.iL = addL.text!
            
            appDelegate.saveContext()
        }
        
        self.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
