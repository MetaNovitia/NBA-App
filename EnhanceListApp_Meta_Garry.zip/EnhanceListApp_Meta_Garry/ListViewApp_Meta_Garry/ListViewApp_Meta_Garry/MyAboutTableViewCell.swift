//
//  MyAboutTableViewCell.swift
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 5/15/17.
//  Copyright © 2017 META 2. All rights reserved.
//

import UIKit

class MyAboutTableViewCell: UITableViewCell {

    @IBOutlet var NameLabel: UILabel!
    @IBOutlet var AboutPic: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
