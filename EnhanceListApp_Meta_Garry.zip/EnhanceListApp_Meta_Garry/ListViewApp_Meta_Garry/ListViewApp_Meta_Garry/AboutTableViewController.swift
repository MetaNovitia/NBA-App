//
//  AboutTableViewController.swift
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 5/15/17.
//  Copyright © 2017 META 2. All rights reserved.
//

import UIKit

class AboutTableViewController: UITableViewController {
    
    var Names = ["Garry Fanata", "Meta Novitia"]
    
    var Data = ["Yo! I'm a De Anza student from Indonesia majoring in Computer Science, and I took C++ and Java classes. While making the app, it was quite quick and easy as everything needed to make it was explained in class and in the powerpoints. We took most of the information from the official NBA website and a few from wikipedia. Both of us are fans of basketball, and so this is quite fun to create. Oh, and my favourite team is the Warriors (of course).", "Hi! I'm studying at De Anza College, and is majoring in Computer Science. I'm from Indonesia, currently 16 years old. I've taken C++ courses, and is taking Java and Swift. Most of the codes used in the app is similar to the ones used in class. We tried our best to make the app as appealing as possible. For me, the design is not that complex, but is still satisfactory to look at. I am a huge basketball fan, and absolutely loved the Knicks, even though they're currently in bad shape."]
    
    var Pics = [#imageLiteral(resourceName: "S__19873813"), #imageLiteral(resourceName: "IMG_4144")]
    var Pics2 = [#imageLiteral(resourceName: "S__19873813 copy"), #imageLiteral(resourceName: "IMG_4144 copy")]
    
    override var prefersStatusBarHidden: Bool {
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "AboutCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! MyAboutTableViewCell
        
        // Configure the cell...
        cell.NameLabel?.text = Names[indexPath.row]
        cell.AboutPic?.image = Pics2[indexPath.row]

        
        return cell
    }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowAboutDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let aboutVC = segue.destination as! AboutViewController
                
                aboutVC.NameLabel = Names[indexPath.row]
                aboutVC.PicLabel = Pics[indexPath.row]
                aboutVC.DataLabel = Data[indexPath.row]
            }
            
        }
        
    }
}

