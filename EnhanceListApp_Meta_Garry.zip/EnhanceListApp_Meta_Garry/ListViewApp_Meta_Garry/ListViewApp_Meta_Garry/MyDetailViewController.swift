//
//  MyDetailViewController.swift
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 5/11/17.
//  Copyright © 2017 META 2. All rights reserved.
//

import UIKit

class MyDetailViewController: UIViewController {
    
    override var prefersStatusBarHidden: Bool {
        return true
    }

    @IBOutlet var Team: UILabel!
    @IBOutlet var ImageLabel: UIImageView!
    @IBOutlet var Info: UITextView!
    @IBOutlet var TeamW: UILabel!
    @IBOutlet var TeamL: UILabel!
    
    var NBADetail : ObjectMO!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.Team.text = self.NBADetail.iTeams
        self.ImageLabel.image = UIImage(data: self.NBADetail.iImage as! Data)
        self.Info.attributedText = self.NBADetail.iInfo as! NSAttributedString
        self.TeamW.text = self.NBADetail.iW
        self.TeamL.text = self.NBADetail.iL
        
        
        
        self.ImageLabel.alpha = 0
        UIView.animate(withDuration: 3, animations: {self.ImageLabel.alpha = 1})
        
        var rotationTransform : CATransform3D = CATransform3DIdentity
        rotationTransform = CATransform3DTranslate(rotationTransform, -250, -250, 0)
        var rotationTransform2 : CATransform3D = CATransform3DIdentity
        rotationTransform2 = CATransform3DTranslate(rotationTransform, -250, -250, 0)
        self.TeamW.layer.transform = rotationTransform
        UIView.animate(withDuration: 3, animations: {self.TeamW.layer.transform = CATransform3DIdentity})
        self.TeamL.layer.transform = rotationTransform2
        UIView.animate(withDuration: 3, animations: {self.TeamL.layer.transform = CATransform3DIdentity})
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }

    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    

}
