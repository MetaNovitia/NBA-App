//
//  AboutViewController.swift
//  ListViewApp_Meta_Garry
//
//  Created by META 2 on 5/15/17.
//  Copyright © 2017 META 2. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBOutlet var ShowName: UILabel!
    @IBOutlet var ShowPic: UIImageView!
    @IBOutlet var ShowData: UILabel!
    
    
    var DataLabel : String!
    var PicLabel : UIImage!
    var NameLabel : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.ShowName.text = self.NameLabel
        self.ShowPic.image = self.PicLabel
        self.ShowData.text = self.DataLabel
        }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    
    
}
